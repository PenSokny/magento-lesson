<?php
/**
 * Created by PhpStorm.
 * User: duccanh
 * Date: 23/12/2015
 * Time: 23:02
 */
namespace Magenest\Training\Controller\Adminhtml\Lesson;

use Magento\Backend\App\Action;

class MassStatus extends \Magento\Backend\App\Action
{
    /**
     * Update blog post(s) status action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     * @throws \Magento\Framework\Exception\LocalizedException|\Exception
     */
    public function execute()
    {
        $testIds = $this->getRequest()->getParam('lesson');
        if (!is_array($testIds) || empty($testIds)) {
            $this->messageManager->addError(__('Please select lesson(s).'));
        } else {
            try {
                $status = (int) $this->getRequest()->getParam('active');
                foreach ($testIds as $testId) {
                    $post = $this->_objectManager->get('Magenest\Training\Model\Lesson')->load($testId);
                    $post->setActive($status)->save();
                }
                $this->messageManager->addSuccess(
                    __('A total of %1 record(s) have been updated.', count($testId))
                );
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
        }
        return $this->resultRedirectFactory->create()->setPath('*/*/index');
    }

}
