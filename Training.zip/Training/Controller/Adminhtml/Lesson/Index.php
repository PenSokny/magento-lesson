<?php
/**
 * Created by PhpStorm.
 * User: duccanh
 * Date: 26/01/2016
 * Time: 00:26
 */
namespace Magenest\Training\Controller\Adminhtml\Lesson;
use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action;

class Index extends Action {

    public function execute()
    {
        /**
         * @var \Magento\Backend\Model\View\Result\Page $resultPage
         */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->setActiveMenu('Magenest_Training::training');
        $resultPage->getConfig()->getTitle()->prepend(__('Manage Lesson'));
        return $resultPage;
    }
}