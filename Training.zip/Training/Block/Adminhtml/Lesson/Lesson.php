<?php
/**
 * Created by PhpStorm.
 * User: canh
 * Date: 25/01/2016
 * Time: 09:33
 */
namespace Magenest\Training\Block\Adminhtml\Lesson;

class Lesson extends \Magento\Backend\Block\Widget\Grid\Container {

    protected function _construct()
    {
        $this->_blockGroup = 'Magenest_Training';
        $this->_controller = 'adminhtml_lesson';
        $this->_headerText = __('Manage Lesson');
        $this->_addButtonLabel = __('Add Lesson');
        parent::_construct();
//        $this->removeButton('add');
    }

    protected function _prepareLayout()
    {
        $this->setChild(
            'grid',
            $this->getLayout()->createBlock('Magenest\Training\Block\Adminhtml\Lesson\Grid', 'training.lesson.grid')
        );
        return parent::_prepareLayout();
    }


}
