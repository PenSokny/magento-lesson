<?php
/**
 * Created by PhpStorm.
 * User: canh
 * Date: 25/01/2016
 * Time: 10:58
 */
namespace Magenest\Training\Block\Adminhtml\Lesson\Edit;

/**
 * Admin page left menu
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('post_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Lesson'));
    }


}
