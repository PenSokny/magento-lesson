<?php
/**
 * Created by PhpStorm.
 * User: canh
 * Date: 25/01/2016
 * Time: 11:10
 */
namespace Magenest\Training\Block\Adminhtml\Lesson\Edit\Tab;

/**
 * Blog post edit form main tab
 */
class Content extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @var \Magenest\GiftRegistry\Model\Status
     */
    protected $_status;

    /**
     * @var \Magenest\GiftRegistry\Model\TypeFactory
     */
    protected $_feedbackFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Magenest\GiftRegistry\Model\Status $status
     * @param \Magenest\GiftRegistry\Model\EventFactory $eventFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Magenest\Training\Model\Status $status,
        \Magenest\Training\Model\LessonFactory $feedbackFactory,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        $this->_feedbackFactory = $feedbackFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('lesson');

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('page_');


        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Lesson Content')]);
        if($model->getId()){
            $fieldset->addField(
                'id',
                'hidden',
                ['name' => 'id']
            );
        }
        $fieldset->addField(
            'lesson',
            'text',
            [
                'name' => 'lesson',
                'label' => __('Lesson'),
                'title' => __('Lesson'),
                'required' => true,
                'value' => 'abc'
            ]
        );

        $fieldset->addField(
            'content',
            'text',
            [
                'name' => 'content',
                'label' => __('Content'),
                'title' => __('Content'),
                'required' => true,
                'value' => 'abc'
            ]
        );

        // Setting custom renderer for content field to remove label column
        $fieldset->addField(
            'active',
            'select',
            [
                'label' => __('Status'),
                'title' => __('Status'),
                'name' => 'active',
                'required' => true,
                'options' => $this->_status->getOptionArray(),
            ]
        );
        $form->setValues($model->getData());
        $this->setForm($form);
        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Content');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Content');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

}
