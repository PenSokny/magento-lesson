<?php
/**
 * Created by PhpStorm.
 * User: duccanh
 * Date: 26/01/2016
 * Time: 00:06
 */
namespace Magenest\Training\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table as Table;

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        /*
         * magenest_training_lesson
         */
        $table = $installer->getConnection()
            ->newTable($installer->getTable('magenest_training_lesson'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'ID'
            )->addColumn(
                'lesson',
                Table::TYPE_TEXT,
                null,
                ['nullable' => false],
                'Lesson'
            )->addColumn(
                'content',
                Table::TYPE_TEXT,
                null,
                ['nullable' => false],
                'SContent'
            )->addColumn(
                'active',
                Table::TYPE_SMALLINT,
                null,
                ['nullable' => false],
                'Active'
            )->setComment('Table List');

        $installer->getConnection()->createTable($table);

        $installer->endSetup();

    }
}