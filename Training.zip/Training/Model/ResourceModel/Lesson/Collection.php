<?php
/**
 * Created by PhpStorm.
 * User: duccanh
 * Date: 26/01/2016
 * Time: 00:13
 */
namespace Magenest\Training\Model\ResourceModel\Lesson;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection{
    protected function _construct()
    {
        $this->_init('Magenest\Training\Model\Lesson', 'Magenest\Training\Model\ResourceModel\Lesson');
    }
}