<?php
/**
 * Created by PhpStorm.
 * User: duccanh
 * Date: 26/01/2016
 * Time: 00:12
 */
namespace Magenest\Training\Model\ResourceModel;

class Lesson extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb{
    /**
     *
     */
    protected function _construct()
    {
        // TODO: Implement _construct() method.
        $this->_init('magenest_training_lesson','id');
    }
}