<?php
/**
 * Created by PhpStorm.
 * User: duccanh
 * Date: 26/01/2016
 * Time: 00:12
 */
namespace Magenest\Training\Model;

use Magenest\Training\Model\ResourceModel\Lesson as ResourceLesson;
use Magenest\Training\Model\ResourceModel\Lesson\Collection;

class Lesson extends \Magento\Framework\Model\AbstractModel
{
    protected $_eventPrefix = 'lesson';

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ResourceLesson $resource,
        Collection $resourceCollection,
        array $data = []
    ){
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }
    public function getDataCollection(){
        $collection = $this->getCollection()->addFieldToSelect('*');

        return $collection;
    }

}